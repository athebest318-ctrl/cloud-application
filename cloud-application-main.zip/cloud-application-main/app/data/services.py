from sqlalchemy import String, Integer, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base  # или откуда у вас импортируется Base

class Service(Base):
    __tablename__ = "services"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    type_id: Mapped[int] = mapped_column(ForeignKey("service_types.id"))
    status: Mapped[str] = mapped_column(String(20))
    
    # 1. Поле для первой миграции (Задание 4)
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)